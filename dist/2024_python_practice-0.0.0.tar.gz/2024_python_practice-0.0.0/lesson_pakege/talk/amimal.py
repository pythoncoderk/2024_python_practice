from lesson_pakege.tools import utels

def sing():
    return "***********************"

def cry():
    return utels.say_twice("##################")