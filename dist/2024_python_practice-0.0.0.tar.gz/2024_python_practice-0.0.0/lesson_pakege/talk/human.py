# from lesson_pakege.tools import utels
from ..tools import utels

def sing():
    return "sing"

def cry():
    return utels.say_twice("cry")