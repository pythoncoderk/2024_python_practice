from setuptools import setup

setup(
    name='2024_python_practice',
    version='',
    packages=['lesson_pakege', 'lesson_pakege.talk', 'lesson_pakege.tools'],
    url='',
    license='',
    author='a',
    author_email='',
    description=''
)
